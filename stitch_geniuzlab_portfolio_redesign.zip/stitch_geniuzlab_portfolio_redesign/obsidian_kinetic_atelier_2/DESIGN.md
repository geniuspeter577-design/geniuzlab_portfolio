---
name: Obsidian Kinetic Atelier
colors:
  surface: '#121315'
  surface-dim: '#121315'
  surface-bright: '#38393b'
  surface-container-lowest: '#0d0e10'
  surface-container-low: '#1b1c1e'
  surface-container: '#1f2022'
  surface-container-high: '#292a2c'
  surface-container-highest: '#343537'
  on-surface: '#e3e2e5'
  on-surface-variant: '#bbcbbb'
  inverse-surface: '#e3e2e5'
  inverse-on-surface: '#303033'
  outline: '#859586'
  outline-variant: '#3c4a3e'
  surface-tint: '#2be282'
  primary: '#81ffab'
  on-primary: '#00391b'
  primary-container: '#32e685'
  on-primary-container: '#006233'
  inverse-primary: '#006d3a'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#89fcc7'
  on-tertiary: '#003825'
  tertiary-container: '#6bdfac'
  on-tertiary-container: '#006143'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#5dff9d'
  primary-fixed-dim: '#2be282'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#00522a'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#121315'
  on-background: '#e3e2e5'
  surface-variant: '#343537'
typography:
  display-hero:
    fontFamily: Outfit
    fontSize: 80px
    fontWeight: '800'
    lineHeight: 84px
    letterSpacing: -0.045em
  display-hero-mobile:
    fontFamily: Outfit
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.035em
  headline-xl:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '800'
    lineHeight: 60px
    letterSpacing: -0.04em
  headline-xl-mobile:
    fontFamily: Outfit
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Outfit
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Outfit
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-lead:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Geist
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.14em
  label-meta:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-button:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-desktop: 2rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style
The brand personality embodies an ultra-premium, dark cinematic creative atelier designed for elite creative agencies, multidisciplinary design studios, and visionary creative directors. It marries the brutalist discipline of high-fashion editorial print with the electric kineticism of modern digital motion laboratories. The experience should evoke raw authority, technical mastery, and visceral prestige—immersing the visitor in an avant-garde digital darkroom where creative artifacts command singular focus.

The visual style blends:
- **Cinematic Darkroom Minimalism:** Unforgiving deep obsidian blacks and dark charcoal canvas tiers that eliminate visual noise and elevate high-resolution creative media.
- **Electric High-Contrast Accents:** Strategic bursts of bioluminescent neon emerald and electric lime that slice through low-key surfaces to steer eye movement and mark key interactive conversions.
- **Architectural Brutalism:** Razor-sharp hairlines, uppercase geometric micro-metadata, tight-tracked headline typography, and structured pill containers creating high-fashion editorial rhythm.

## Colors
The color architecture operates on high-contrast theatrical values. The primary mode is dark by default, supported by an archival editorial light theme for selective documentation and case study deep-dives.

### Surface Roles (Dark Mode)
- **Root Canvas (`#090A0C`)**: An ultra-deep, light-absorbing obsidian void that sets the cinematic atmosphere.
- **Surface Low (`#0F1115`)**: Tactical dark charcoal applied to primary structural containers, headers, and media frames.
- **Surface Mid (`#16181D`)**: Elevated interactive container surface for cards, input modules, and floating capsules.
- **Surface High (`#22262F`)**: Hover elevations, elevated states, and active tool surfaces.
- **Surface Hairline (`#1F2937` / `rgba(255, 255, 255, 0.08)`)**: Precision-milled sub-pixel boundaries framing components without graphic weight.

### Accent Roles
- **Hero Primary (`#32E685`)**: Bioluminescent neon emerald green reserved for primary calls to action, active indicators, and critical conversion triggers.
- **Secondary Lime-Emerald (`#10B981`)**: High-luminance accent used for focus borders, live status beacons, and active category tags.
- **Deep Contrast Ink (`#032612`)**: Extreme dark green-black ink applied on top of solid neon emerald fills to ensure WCAG AAA contrast compliance.

### Typography & Editorial Tones
- **Stark White (`#F8FAFC`)**: High-impact editorial headlines, project display titles, and hero statements.
- **Muted Steel Grey (`#94A3B8`)**: Secondary explanatory narratives, body copy, and metadata subtitles.
- **Dark Ash Grey (`#64748B`)**: Tertiary captions, timestamps, inactive borders, and understated placeholders.

### Selective Editorial Light Theme
- **Paper Canvas (`#F8F9F7`)**: Tactile bleached alabaster Japanese paper aesthetic.
- **Light Surface Container (`#FFFFFF`)**: Pure gallery card elevations with linen hairline borders (`#E2E8F0`).
- **Deep Forest Ink (`#090A0C` / `#0F172A`)**: Razor-sharp editorial typographic contrast.
- **Deep British Racing Green (`#059669`)**: Grounded luxury accent for light mode interaction.

## Typography
The typographic system pairs high-impact editorial geometry with technical monospace precision:

- **Display & Headlines (`Outfit`)**: Heavyweight geometric sans-serif characterized by tight apertures and severe negative letter tracking (`-0.03em` to `-0.045em`). Displays deliver high-fashion power and dramatic scale. Key hero headings may highlight initial anchor words in the electric neon emerald tone.
- **Editorial Body (`Geist`)**: A crisp, neutral neo-grotesque sans-serif offering transparent readability across long-form case studies, client summaries, and atelier service breakdowns. Measures are capped at 65 characters to preserve scanning comfort.
- **Micro & Telemetry Labels (`Space Grotesk`)**: Technical, uppercase-only, monospaced-attitude typography with wide tracking (`0.06em` to `0.14em`). Used for status badges, section kickers, category filters, and numerical metadata counters.

## Layout & Spacing
The layout leverages a disciplined 12-column grid system paired with strict 4px/8px incremental rhythm units.

### Canvas Grid Model
- **Mobile (<640px)**: 4 columns, single-column fluid stacking, 16px lateral margin, 16px gutter.
- **Tablet (640px - 1023px)**: 8 columns, 32px lateral margin, 20px gutter.
- **Desktop (>=1024px)**: 12 columns with a constrained max content container of `1240px`, flanked by generous fluid outer gutters. Editorial reading columns for case studies are held to a focused `860px` max measure.

### Vertical Cadence & Safe Padding
- Section containers breathe through generous fluid spacing (`clamp(3.5rem, 8vw, 7rem)`), presenting each body of work as an isolated gallery installation.
- Mobile bottom clearance explicitly injects `calc(5.5rem + env(safe-area-inset-bottom))` to prevent interference with the floating bottom capsule bar.

## Elevation & Depth
Depth is realized through structural darkroom tiers, frosted glassmorphism, and neon optical blooms rather than traditional grey drop shadows.

- **Atmospheric Bloom / Neon Glow**: Interactive points-of-interest and active indicator capsules emit diffused emerald luminescence: `box-shadow: 0 0 24px -4px rgba(50, 230, 133, 0.45)`.
- **Low-Contrast Ghost Outlines**: Surfaces are framed by hairline borders (`1px solid rgba(255, 255, 255, 0.08)` or `#1F2937`) to define form boundaries against deep obsidian backdrops without adding visual clutter.
- **Frosted Translucent Layers**: Floating navigation bars and modal overlays utilize high-density frosted backdrops (`background: rgba(15, 17, 21, 0.82)`, `backdrop-filter: blur(20px)`), allowing ambient movement to shimmer behind structural chrome.
- **Cinematic Ambient Shadows**: Large portfolio showcase cards rely on deep, diffused shadows (`box-shadow: 0 24px 48px -12px rgba(0, 0, 0, 0.75)`) to achieve separation from the root canvas.

## Shapes
The shape language combines functional `rounded-2xl` (16px) chassis structures with sleek full-pill (`rounded-full`, 9999px) action elements:

- **Cards, Panels & Fields**: Molded with `1rem` (16px) corner radii for structural balance.
- **Pills, Chips & CTAs**: Executed with `9999px` full-capsule geometries, conveying speed, tactile precision, and dynamic motion.
- **Action Dials**: Circular 1:1 ratio controls (42px to 48px diameter) with perfectly centered iconography.

## Components

### Buttons
- **Primary Action Pill**: Full pill shape (`border-radius: 9999px`), solid neon emerald fill (`#32E685`), deep obsidian text (`#032612`), uppercase `Space Grotesk` font (`0.75rem`, tracking `0.06em`). Infused with `box-shadow: 0 0 20px -3px rgba(50, 230, 133, 0.4)`. Transitions to `brightness(1.08)` and `-1px` vertical lift on hover.
- **Secondary Ghost Pill**: Frosted translucent core with a 1px boundary (`rgba(255, 255, 255, 0.12)`), white typography (`#F8FAFC`), shifting to a solid white pill with deep black typography on hover.
- **Icon Dial Button**: 42x42px circular container, obsidian-charcoal fill (`#16181D`), hairline outline, hosting a centered monochrome glyph that transitions to neon emerald upon interaction.

### Chips & Filter Pills
- **Category Filter**: Capsule badge with 1px border. Inactive state features dark charcoal background (`#0F1115`), hairline border, and muted text (`#94A3B8`). Active state swaps to high-voltage neon emerald fill (`#32E685`), deep dark typography, and a subtle glowing rim.

### Project & Portfolio Cards
- **Structure**: 16px corner radius container, dark charcoal body (`#0F1115`), hairline boundary (`rgba(255, 255, 255, 0.08)`), locking an aspect-ratio-controlled image/video frame.
- **Micro-Badges**: Frosted glass floating pill in the top-left offset (`backdrop-filter: blur(12px)`, background `rgba(9, 10, 12, 0.75)`) displaying the discipline metadata in neon emerald.
- **Action Disc**: Bottom-right floating circular emerald disc featuring an angled arrow icon (`ArrowUpRight`) that translates `2px` diagonally on card hover.

### Navigation Chrome
- **Sticky Atelier Header**: Viewport-anchored header with frosted backing (`rgba(9, 10, 12, 0.82)`, `backdrop-filter: blur(16px)`), slim bottom hairline, brand mark GENIUZLAB in stark white with neon emerald accents, and quick-access theme and search controls.
- **Floating Island Capsule (Bottom Nav)**: Centered pill dock (`bottom: calc(1rem + env(safe-area-inset-bottom))`, max-width 420px), obsidian slate fill (`rgba(22, 24, 29, 0.88)`), frosted glass blur (`24px`), dual ambient and emerald rim shadow. Active link translates to a stark white capsule badge with deep forest text and a vibrant emerald glow.

### Form Fields & Inputs
- **Input & Textarea Canvas**: 52px height (inputs) or 140px min-height (textareas), 16px corner radius, dark charcoal fill (`#0F1115`), 1px outline (`rgba(255, 255, 255, 0.08)`).
- **Focus Mechanics**: Transitions to bright emerald outline (`#10B981`) paired with an ambient glow (`box-shadow: 0 0 0 3px rgba(50, 230, 133, 0.2)`). Labels remain strictly uppercase in `Space Grotesk` above each field.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes**: 18x18px squares with 4px corners, charcoal border. Checked state fills with `#32E685` and a stark obsidian checkmark.
- **Radio Buttons**: 18x18px concentric circle, transitioning to a luminous emerald core dot when selected.

### Atelier Status Indicator
- **Live Signal Beacon**: Micro-pill capsule showcasing a 7px pulsing neon emerald dot (`#32E685`) paired with uppercase monospace status copy: `STUDIO STATUS // OPEN FOR COMMISSIONS`.