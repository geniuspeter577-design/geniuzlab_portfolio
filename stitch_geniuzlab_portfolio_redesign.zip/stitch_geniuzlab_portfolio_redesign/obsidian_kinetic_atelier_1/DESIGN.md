---
name: Obsidian Kinetic Atelier
colors:
  surface: '#fbf8ff'
  surface-dim: '#dad9e3'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f2fd'
  surface-container: '#eeedf7'
  surface-container-high: '#e8e7f1'
  surface-container-highest: '#e3e1ec'
  on-surface: '#1a1b22'
  on-surface-variant: '#47464a'
  inverse-surface: '#2f3038'
  inverse-on-surface: '#f1effa'
  outline: '#78767b'
  outline-variant: '#c8c5ca'
  surface-tint: '#5f5e60'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1d'
  on-primary-container: '#858386'
  inverse-primary: '#c8c6c8'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#009668'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e5e1e4'
  primary-fixed-dim: '#c8c6c8'
  on-primary-fixed: '#1c1b1d'
  on-primary-fixed-variant: '#474649'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#fbf8ff'
  on-background: '#1a1b22'
  surface-variant: '#e3e1ec'
typography:
  display-xl:
    fontFamily: Outfit
    fontSize: 4.5rem
    fontWeight: '700'
    lineHeight: 4.75rem
    letterSpacing: -0.03em
  display-xl-mobile:
    fontFamily: Outfit
    fontSize: 2.75rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.025em
  display-lg:
    fontFamily: Outfit
    fontSize: 3.5rem
    fontWeight: '600'
    lineHeight: 3.75rem
    letterSpacing: -0.025em
  display-lg-mobile:
    fontFamily: Outfit
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 2.25rem
    fontWeight: '600'
    lineHeight: 2.625rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Outfit
    fontSize: 1.75rem
    fontWeight: '500'
    lineHeight: 2.125rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Outfit
    fontSize: 1.25rem
    fontWeight: '500'
    lineHeight: 1.625rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Outfit
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  body-md:
    fontFamily: Outfit
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.6rem
    letterSpacing: 0em
  body-sm:
    fontFamily: Outfit
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0em
  label-lg:
    fontFamily: Outfit
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.125rem
    letterSpacing: 0.08em
  label-md:
    fontFamily: Outfit
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.12em
  label-sm:
    fontFamily: Outfit
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.15em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-tablet: 2.5rem
  margin-desktop: 4rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-2xl: 4rem
  space-3xl: 6rem
---

## Brand & Style

This design system expresses a luxury editorial creative studio aesthetic tailored for high-end digital showcases, curated portfolios, and design ateliers. Balancing the tactile gravitas of Swiss editorial art direction with contemporary interactive kinetic grace, the visual language communicates precision, authorial clarity, and uncompromising craftsmanship.

### Aesthetic Foundation
- **Modern Architectural Editorial:** Structural hierarchy driven by crisp, hairline rule divisions, deliberate asymmetric pauses, and generous gallery margins.
- **Human-Crafted Restraint:** Elimination of gratuitous sci-fi telemetry, neon overload, or decorative tech noise in favor of pristine typographic proportions, intentional whitespace, and fine-line geometry.
- **Kinetic Precision:** Strategic bursts of emerald green that act as purposeful signals of state change, validation, and curation rather than continuous decoration.
- **Emotional Resonance:** Quiet confidence, museum-grade curation, razor-sharp focus, and tactile prestige reminiscent of heavy-stock cold-pressed paper and obsidian ink.

## Colors

The palette reproduces the chromatic discipline of a physical print atelier: deep carbon-black ink deposited on warm, balanced archival paper surfaces, accented strictly by razor-sharp kinetic emerald.

### Surface Tiers
- **Canvas Base (`#FAFAFA`):** Warm alabaster backdrop providing an organic, non-fatiguing gallery foundation.
- **Canvas Secondary (`#F4F4F5`):** Crisp archival paper tone used for structural page segments, alternated sections, and full-bleed framing.
- **Surface Elevation (`#FFFFFF`):** Pure pristine white reserved for elevated cards, modular sheets, floating controls, and image framing.
- **Surface Muted (`#F0F1F3`):** Neutral tone for input troughs, interactive hover plates, and inset editorial metadata panels.

### Editorial & Hairline Borders
- **Border Default (`#E4E4E7`):** Whisper-thin architectural line dividing grids, headers, and modular units.
- **Border Strong (`#D4D4D8`):** Deepened divider for structural boundaries, active input rings, and pinned navigation thresholds.

### Typographic Inks
- **Text Primary (`#09090B`):** Obsidian black ink yielding stark contrast and decisive hierarchy across all display headings and core text.
- **Text Secondary (`#52525B`):** Deep slate charcoal for editorial context, body paragraphs, and secondary descriptors.
- **Text Muted (`#71717A`):** Atmospheric charcoal for timestamps, archival indexes, footnote marks, and uppercase tracking labels.

### Kinetic Emerald Accent
- **Accent Primary (`#059669`):** Deep kinetic emerald for interactive focal triggers, selected states, and core action points.
- **Accent Vibrant (`#10B981`):** Luminous emerald for indicators, dynamic badges, and focused cursor cues.
- **Accent Kinetic Hover (`#047857`):** Deepened forest jade applied under cursor pressure and pressed button states.
- **Accent Glow (`#32E685`):** High-energy electric micro-accents for live pulse dots and momentary state changes.

## Typography

The typographic engine uses **Outfit** across all roles to achieve a cohesive, architectural dialogue between bold editorial titles and tracked metadata.

### Typographic Rules
- **Display & Headlines:** Set with tight tracking (`-0.03em` to `-0.015em`) and condensed line heights to emulate high-end art monographs. Headlines must avoid centering; rely on left-aligned anchors with generous whitespace runoffs.
- **Editorial Sub-Headers:** Use medium weights (`500`) paired with secondary ink (`#52525B`) to establish immediate reading contrast.
- **Tracked Metatext & Indexes:** Set `label-sm` and `label-md` exclusively in uppercase with expanded tracking (`+0.08em` to `+0.15em`). These serve as exhibition coordinates, section stamps, category identifiers, and architectural footnotes.
- **Proportional Discipline:** Maintain a vertical rhythm where body text never competes with display weights. Body copy features relaxed line heights (`1.6` to `1.75`) to preserve readability against clean gallery backdrops.

## Layout & Spacing

Layouts follow an asymmetric architectural grid system that values expansive negative space over compressed dashboard density. 

### Grid Blueprint
- **Desktop (12 Columns):** Fluid container constrained to `1440px` max-width. Gutter fixed at `2.5rem` (`40px`), outer margins at `4rem` (`64px`). Grid lines align strictly with hairline border rules (`#E4E4E7`).
- **Tablet (8 Columns):** Fluid container, `1.5rem` (`24px`) gutters, `2.5rem` (`40px`) margins. Multi-column cards compress into alternating paired modules.
- **Mobile (4 Columns):** Fluid edge-to-edge canvas with `1.25rem` (`20px`) margins and `1rem` (`16px`) gutters. Typography collapses to designated mobile display tokens.

### Spacing Rhythm
- Sectional transitions employ monumental spacing (`space-2xl` and `space-3xl`) to create gallery pacing between works.
- Internal component groupings use strict multiples of `4px` (`space-xs` through `space-md`), keeping interface elements compact and anchored within larger whitespace expanses.

## Elevation & Depth

Depth in this system is planar, tactile, and physical, relying on paper layering, whisper-thin boundaries, and diffused ambient shadows rather than dense drop shadows.

### Atmospheric Surface Tiers
- **Tier 0 (Base Canvas):** `#FAFAFA` — The ground plane.
- **Tier 1 (Framed Containers & Cards):** `#FFFFFF` bordered by a 1px solid `#E4E4E7` hairline rule. Depth is conveyed by the stark tonal purity of white resting upon alabaster.
- **Tier 2 (Floating Floating Drawers & Toolbars):** `#FFFFFF` paired with an ultra-diffused, ambient shadow: `0 12px 32px -4px rgba(9, 9, 11, 0.04), 0 4px 12px -2px rgba(9, 9, 11, 0.02)`.
- **Tier 3 (Modals & Overlays):** Background backdrop veil set to `rgba(250, 250, 250, 0.85)` with a `12px` lens blur, maintaining continuous atmospheric luminosity beneath overlaid dialogue cards.

### Hairline Architecture
All elevation relies fundamentally on the **1px hairline rule**. Borders never draw attention to themselves; they exist as crisp cutting lines separating content blocks cleanly.

## Shapes

The design uses a **Soft Architectural (`1`)** shape language. Geometry stays structured, tailored, and confident, avoiding excessive circular roundness while softening extreme industrial corners.

### Radius Values
- **Base Components (Inputs, Buttons, Badges):** `0.25rem` (`4px`) — sharp and tailored.
- **Cards, Panels, & Media Frames:** `0.5rem` (`8px`) — structural containment with subtle corner softening.
- **Modals & Atelier Viewports:** `0.75rem` (`12px`) — soft perimeter for elevated content sheets.
- **Indicator Dots & Dynamic Status Chips:** Fully pill-shaped or circular purely to indicate status or kinetic state.

## Components

### Buttons & Interactive Triggers
- **Primary Kinetic Button:** Obsidian black fill (`#09090B`), pristine white text (`#FFFFFF`), `0.25rem` radius, `0.875rem` uppercase label tracking (`label-lg`). Hover state triggers a kinetic micro-shift: transition border or subtle background bloom to emerald hover (`#047857`) with ease-out timing (`150ms`).
- **Secondary Atelier Button:** Pure white background (`#FFFFFF`), 1px hairline border (`#E4E4E7`), obsidian text (`#09090B`). On hover: border deepens to `#09090B` with zero offset shift.
- **Text Link Action:** Obsidian text with a bottom 1px accent hairline positioned 4px below text. Under hover, the line expands smoothly in emerald green (`#059669`).

### Chips & Curation Badges
- **Editorial Category Chip:** Light neutral surface (`#F0F1F3`), no border, muted slate text (`#52525B`), uppercase tracking (`label-sm`).
- **Kinetic Status Badge:** Transparent ground with a 1px border (`#E4E4E7`), accompanied by an inline `6px` glowing emerald circle (`#32E685`), followed by obsidian tracking text.

### Form Inputs & Selectors
- **Text Input Field:** `#FFFFFF` ground, 1px `#E4E4E7` border, `0.25rem` corner radius, `space-md` inner padding. Text set in `body-md` (`#09090B`). Placeholder in `#71717A`.
- **Focus State:** Border transitions crisply to emerald (`#059669`) with a 0 0 0 1px ring; no soft outer neon glow.
- **Checkboxes & Radios:** Minimalist square (`4px` radius) or circle, bordered by `#D4D4D8`. Checked state fills with `#09090B` housing a sharp emerald verification tick (`#10B981`).

### Cards & Gallery Frames
- **Atelier Portfolio Card:** `#FFFFFF` ground, framed by a continuous 1px `#E4E4E7` outline. Images within the card feature an intentional 1px inset margin or full bleed bound by internal dividers. Hover induces an ambient depth lift and title text shift from `#09090B` to emerald (`#059669`).
- **Curatorial List:** Modular list item separated by hairline dividers (`#E4E4E7`). Monospaced or tracked uppercase numbering (`01`, `02`, `03`) in `#71717A` aligned to the far left, title in `headline-sm`, and kinetic indicator to the right.

### Navigation & Header Bar
- **Pinned Top Bar:** `#FAFAFA` with subtle frosted translucency (`backdrop-filter: blur(8px)`), anchored by a bottom 1px border (`#E4E4E7`). Features razor-sharp branding, spaced uppercase menu labels, and a live emerald atelier status indicator.